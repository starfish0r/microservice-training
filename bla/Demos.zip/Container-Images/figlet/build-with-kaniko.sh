#!/bin/bash

docker run --rm -v $(pwd):/workspace  \
gcr.io/kaniko-project/executor:latest \
--context=/workspace \
--tarPath /workspace/figlet.tar \
--destination=latest --force