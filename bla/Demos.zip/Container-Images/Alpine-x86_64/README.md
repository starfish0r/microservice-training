# Alpine Linux Example

Alpine Example from [github](https://github.com/gliderlabs/docker-alpine)

Extract tar with

```bash
tar xf rootfs.tar.xz
```
