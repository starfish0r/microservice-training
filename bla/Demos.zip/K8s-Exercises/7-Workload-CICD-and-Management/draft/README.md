# development flow

based on [Draft](https://github.com/Azure/draft)

* $ draft config set registry docker.io/myusername
* $ draft create
* edit draft.toml
* $ draft up
* $ draft connect
* edit code
* repeat up and connect
* $ draft delete