# create from folder

kubectl create configmap game-config --from-file=./config-folder

# create from file

kubectl create configmap game-config-2 --from-file=./config-folder/game.properties --from-file=./config-folder/ui.properties
