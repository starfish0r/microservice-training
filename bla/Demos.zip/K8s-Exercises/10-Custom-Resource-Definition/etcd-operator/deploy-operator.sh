#!/bin/bash

NAMESPACE=$(kubectl config get-contexts | awk '/^\*/ {print $5}')
if [[ -z "$NAMESPACE" ]]; then
    echo "ERROR: you must not operate on the default namespace"
    exit 1
fi

PS3='ETCD Operator?: '
options=("Create" "Delete" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "Create")
            sed "s/CHANGE_ME/$NAMESPACE/g" operator.template | kubectl apply -f -
            break;
            ;;
        "Delete")
            sed "s/CHANGE_ME/$NAMESPACE/g" operator.template | kubectl delete -f -
            break;
            ;;
        "Quit")
            break
            ;;
        *) echo invalid option;;
    esac
done
