# Sharded Redis

## using

* [twemproxy](https://github.com/twitter/twemproxy)
* [Redis](https://redis.io/)

## test

* kubectl apply all yamls (kubectl apply -f .)
* exec into the main app container with

```bash
kubectl exec -it application -c main-app-container /bin/sh

# redis-cli -h localhost
localhost:6379> rpush aaaaaaaa "-"
(integer) 1
localhost:6379> rpush aa "-"
(integer) 2
localhost:6379> rpush dddddddd "-"
(integer) 3
localhost:6379> lrange job 0 -1
localhost:6379> keys *
```

* check different redis instaces with

```bash
redis-cli -h redis-sharded-0.redis
redis:6379> keys *

redis-cli -h redis-sharded-1.redis
redis:6379> keys *

redis-cli -h redis-sharded-2.redis
redis:6379> keys *
```

* for checking state

```bash
# apk add --no-cache curl
# curl localhost:6222
```
