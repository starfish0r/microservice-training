# Setup

taken from <https://github.com/kubernetes-incubator/external-storage/tree/master/docs/demo/hostpath-provisioner>

* kubectl create -f provisioner.yaml (wait for creation)
* kubectl create -f class.yaml
* kubectl create -f web.yaml

# Cleanup

* kubectl delete -f web.yaml
* kubectl delete -f class.yaml
* kubectl delete -f provisioner.yaml
* kubectl delete pvc --all
* kubectl delete pv --all

# for Rook you need to create a secret with

* kubectl -n default get secret rook-rook-user -o json | jq '.metadata.namespace = "<namespace>"' | kubectl apply -f -